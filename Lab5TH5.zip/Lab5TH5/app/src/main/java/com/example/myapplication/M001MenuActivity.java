package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.OvershootInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class M001MenuActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<Zodiac> list;
    private Zodiac current;

    private ImageView ivResult;
    private TextView tvName, tvContent;
    private View btnMore;

    private ValueAnimator glowAnimator;
    private GradientDrawable currentGlowDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_frg_menu); // layout mới

        list = ZodiacData.getAll(); // danh sách 12 cung hoàng đạo

        mapViews();
        setClickEvents();

        // Xoay vòng tròn nền (nếu muốn)
        Animation rotate = AnimationUtils.loadAnimation(this, R.anim.rotate_bg);
        findViewById(R.id.center_anchor).startAnimation(rotate);
    }

    private void mapViews() {
        ivResult = findViewById(R.id.iv_result);
        tvName = findViewById(R.id.tv_name);
        tvContent = findViewById(R.id.tv_content);
        btnMore = findViewById(R.id.btn_more);

        btnMore.setOnClickListener(v -> openDetail());
    }

    private void setClickEvents() {
        int[] ids = {
                R.id.ic_aries, R.id.ic_taurus, R.id.ic_gemini, R.id.ic_cancer,
                R.id.ic_leo, R.id.ic_virgo, R.id.ic_libra, R.id.ic_scorpio,
                R.id.ic_sagittarius, R.id.ic_capricorn, R.id.ic_aquarius, R.id.ic_pisces
        };

        for (int i = 0; i < ids.length; i++) {
            ImageView iv = findViewById(ids[i]);
            iv.setTag(i);
            iv.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        int index = (int) v.getTag();
        current = list.get(index);

        // Cập nhật preview
        ivResult.setImageResource(current.getImage());
        tvName.setText(current.getName());
        tvContent.setText(current.getContent());

        startFullEffect((ImageView) v);
    }

    private void openDetail() {
        if (current == null) return;
        Intent intent = new Intent(this, M002DetailActivity.class);
        intent.putExtra("name", current.getName());
        intent.putExtra("image", current.getImage());
        intent.putExtra("content", current.getContent());
        startActivity(intent);
    }

    // ===================================================================
    // Hiệu ứng tổng hợp: Bounce → Rotate → Glow rainbow → Đổi màu
    // ===================================================================
    private void startFullEffect(ImageView iv) {

        // Bounce
        ScaleAnimation bounce = new ScaleAnimation(
                0.7f, 1.2f,
                0.7f, 1.2f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        bounce.setDuration(300);
        bounce.setInterpolator(new OvershootInterpolator());
        iv.startAnimation(bounce);

        // Rotate
        RotateAnimation rotate = new RotateAnimation(
                0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        rotate.setDuration(600);
        iv.startAnimation(rotate);

        // Glow neon rainbow
        addNeonGlow(iv);

        // Rainbow color loop
        startRainbowColorLoop(iv);

        // Tắt glow sau 1.6s
        new Handler().postDelayed(() -> clearGlow(iv), 1600);
    }

    private void startRainbowColorLoop(ImageView iv) {
        int[] rainbow = {
                Color.RED, 0xFFFF7F00, Color.YELLOW,
                Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA
        };

        Handler h = new Handler();
        for (int i = 0; i < rainbow.length; i++) {
            int c = rainbow[i];
            h.postDelayed(() -> iv.setColorFilter(c), i * 120);
        }
        h.postDelayed(iv::clearColorFilter, rainbow.length * 120);
    }

    private void addNeonGlow(View view) {
        view.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.TRANSPARENT);

        int stroke = dpToPx(5);
        gd.setStroke(stroke, Color.WHITE);
        currentGlowDrawable = gd;
        view.setBackground(gd);

        glowAnimator = ValueAnimator.ofFloat(0, 360);
        glowAnimator.setDuration(1800);
        glowAnimator.setRepeatCount(ValueAnimator.INFINITE);
        glowAnimator.addUpdateListener(a -> {
            float hue = (float) a.getAnimatedValue();
            int color = Color.HSVToColor(new float[]{hue, 0.8f, 1f});
            gd.setStroke(stroke, color);
            gd.setAlpha(180);
        });
        glowAnimator.start();
    }

    private void clearGlow(View view) {
        if (glowAnimator != null) {
            glowAnimator.cancel();
            glowAnimator = null;
        }
        currentGlowDrawable = null;
        view.setBackground(null);
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }
}
