package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Mở màn hình Menu 12 cung hoàng đạo
        Intent intent = new Intent(this, M001MenuActivity.class);
        startActivity(intent);

        finish(); // đóng MainActivity cho gọn
    }
}
