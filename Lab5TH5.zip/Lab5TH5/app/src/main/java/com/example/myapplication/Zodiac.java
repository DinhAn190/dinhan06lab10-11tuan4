package com.example.myapplication;

public class Zodiac {
    private final String name;
    private final int image;
    private final String content;

    public Zodiac(String name, int image, String content) {
        this.name = name;
        this.image = image;
        this.content = content;
    }

    public String getName() { return name; }
    public int getImage() { return image; }
    public String getContent() { return content; }
}

