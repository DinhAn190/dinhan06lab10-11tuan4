package com.example.myapplication;

import java.util.ArrayList;

public class ZodiacData {

    public static ArrayList<Zodiac> getAll() {
        ArrayList<Zodiac> list = new ArrayList<>();

        list.add(new Zodiac("Bạch Dương", R.drawable.ic_aries,
                "Nhiệt huyết, năng động, thẳng thắn và luôn tiên phong..."));

        list.add(new Zodiac("Kim Ngưu", R.drawable.ic_taurus,
                "Ổn định, đáng tin cậy, kiên nhẫn và yêu thích sự thoải mái..."));

        list.add(new Zodiac("Song Tử", R.drawable.ic_gemini,
                "Thông minh, linh hoạt, giao tiếp tốt, ham học hỏi..."));

        list.add(new Zodiac("Cự Giải", R.drawable.ic_cancer,
                "Tình cảm, nhạy cảm, quan tâm gia đình và sống rất nội tâm..."));

        list.add(new Zodiac("Sư Tử", R.drawable.ic_leo,
                "Tự tin, mạnh mẽ, hào phóng và có tố chất lãnh đạo..."));

        list.add(new Zodiac("Xử Nữ", R.drawable.ic_virgo,
                "Tỉ mỉ, phân tích tốt, cầu toàn và luôn hoàn hảo trong mọi việc..."));

        list.add(new Zodiac("Thiên Bình", R.drawable.ic_libra,
                "Hòa đồng, tinh tế, công bằng và thích cái đẹp..."));

        list.add(new Zodiac("Bọ Cạp", R.drawable.ic_scorpio,
                "Mạnh mẽ, sâu sắc, bí ẩn và có sức hút đặc biệt..."));

        list.add(new Zodiac("Nhân Mã", R.drawable.ic_sagittarius,
                "Tự do, vui vẻ, thích khám phá và rất lạc quan..."));

        list.add(new Zodiac("Ma Kết", R.drawable.ic_capricorn,
                "Kỷ luật, tham vọng, kiên trì và luôn hướng đến thành công..."));

        list.add(new Zodiac("Bảo Bình", R.drawable.ic_aquarius,
                "Khác biệt, sáng tạo, độc lập và suy nghĩ rất hiện đại..."));

        list.add(new Zodiac("Song Ngư", R.drawable.ic_pisces,
                "Mơ mộng, tình cảm, giàu lòng trắc ẩn và dễ đồng cảm..."));

        return list;
    }
}
