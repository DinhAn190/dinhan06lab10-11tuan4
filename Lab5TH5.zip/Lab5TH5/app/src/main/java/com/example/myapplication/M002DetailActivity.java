package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class M002DetailActivity extends AppCompatActivity {

    private ImageView ivBack, ivZodiac;
    private TextView tvName, tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m002_frg_detail);

        mappingViews();
        getData();
    }

    private void mappingViews() {
        ivBack = findViewById(R.id.iv_back);
        ivZodiac = findViewById(R.id.iv_zodiac);
        tvName = findViewById(R.id.tv_name);
        tvContent = findViewById(R.id.tv_content);

        ivBack.setOnClickListener(v -> finish());
    }

    private void getData() {
        String name = getIntent().getStringExtra("name");
        int img = getIntent().getIntExtra("image", 0);
        String content = getIntent().getStringExtra("content");

        tvName.setText(name);
        ivZodiac.setImageResource(img);
        tvContent.setText(content);
    }
}
