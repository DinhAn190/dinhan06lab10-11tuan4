package com.example.lab3;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab3.StoryEntity;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryViewHolder> {

    private final Context context;
    private final ArrayList<StoryEntity> listStory;
    private final RecyclerView recyclerView;

    public StoryAdapter(Context context, ArrayList<StoryEntity> listStory, RecyclerView recyclerView) {
        this.context = context;
        this.listStory = listStory;
        this.recyclerView = recyclerView;
    }

    @NonNull
    @Override
    public StoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_story, parent, false);
        return new StoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryViewHolder holder, int position) {
        StoryEntity story = listStory.get(position);

        // Set tiêu đề và nội dung
        holder.tvTitle.setText(story.title);
        holder.tvContent.setText(story.content);

        // Rainbow gradient cho nội dung
        startRainbowGradient(holder.tvContent);

        // Nếu là chương cuối cùng, ẩn nút
        if (position == listStory.size() - 1) {
            holder.tvNextChapter.setVisibility(View.GONE);
        } else {
            holder.tvNextChapter.setVisibility(View.VISIBLE);
            holder.tvNextChapter.setOnClickListener(v -> {
                int nextPos = holder.getAdapterPosition() + 1;
                if (nextPos < listStory.size()) {
                    recyclerView.smoothScrollToPosition(nextPos);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return listStory.size();
    }

    public static class StoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvContent, tvNextChapter;

        public StoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvStoryTitle); // tiêu đề chương
            tvContent = itemView.findViewById(R.id.tvShortDesc); // nội dung chương
            tvNextChapter = itemView.findViewById(R.id.tvNextChapter);
        }
    }

    private void startRainbowGradient(TextView textView) {
        final int[] rainbowColors = {
                0xFFFF0000, 0xFFFF7F00, 0xFFFFFF00,
                0xFF00FF00, 0xFF00FFFF, 0xFF0000FF,
                0xFFFF00FF
        };

        ValueAnimator animator = ValueAnimator.ofFloat(0, 1);
        animator.setDuration(3000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(animation -> {
            float progress = (float) animation.getAnimatedValue();
            int width = textView.getWidth();
            if (width > 0) {
                float startX = width * progress;
                float endX = startX + width;
                Shader shader = new LinearGradient(
                        startX, 0, endX, 0,
                        rainbowColors,
                        null,
                        Shader.TileMode.MIRROR
                );
                textView.getPaint().setShader(shader);
                textView.invalidate();
            }
        });
        animator.start();
    }
}

