package com.example.lab3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TopicAdapter extends RecyclerView.Adapter<TopicAdapter.TopicHolder> {

    private final ArrayList<String> list;
    private final Context context;

    // Mảng hình tương ứng với từng topic
    private final int[] images = {
            R.drawable.hinh_jack_ripple
    };

    public TopicAdapter(Context ctx, ArrayList<String> list) {
        this.context = ctx;
        this.list = list;
    }

    @NonNull
    @Override
    public TopicHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_topic, parent, false);
        return new TopicHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TopicHolder holder, int position) {
        holder.tvTopic.setText(list.get(position));
        holder.ivTopic.setImageResource(images[position]); // Gán hình theo thứ tự

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, StoryListActivity.class);
            i.putExtra("topic", list.get(position));
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class TopicHolder extends RecyclerView.ViewHolder {
        TextView tvTopic;
        ImageView ivTopic;

        public TopicHolder(@NonNull View itemView) {
            super(itemView);
            tvTopic = itemView.findViewById(R.id.tvTopic);
            ivTopic = (ImageView) ((ViewGroup) itemView).getChildAt(0); // Lấy ImageView có sẵn
        }
    }
}
