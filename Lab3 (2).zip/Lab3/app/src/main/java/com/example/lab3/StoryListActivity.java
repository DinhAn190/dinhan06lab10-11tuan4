package com.example.lab3;

import android.animation.ValueAnimator;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryListActivity extends AppCompatActivity {

    RecyclerView rcv;
    ArrayList<StoryEntity> listStory = new ArrayList<>();
    String topic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_list);

        rcv = findViewById(R.id.rcvStory);

        topic = getIntent().getStringExtra("topic");

        loadStories();

        StoryAdapter adapter = new StoryAdapter(this, listStory, rcv);
        rcv.setLayoutManager(new LinearLayoutManager(this));
        rcv.setAdapter(adapter);


        // Bắt đầu hiệu ứng rainbow gradient cho TextView hiển thị nội dung story đầu tiên
        // Nếu muốn cho từng item, bạn sẽ chỉnh trong onBindViewHolder của adapter
        new Handler().postDelayed(() -> {
            if (rcv.getChildAt(0) != null) {
                TextView tvContent = rcv.getChildAt(0).findViewById(R.id.tvContent);
                if (tvContent != null) startRainbowGradient(tvContent);
            }
        }, 200);
    }

    private void startRainbowGradient(TextView textView) {
        final int[] rainbowColors = {
                0xFFFF0000, // đỏ
                0xFFFF7F00, // cam
                0xFFFFFF00, // vàng
                0xFF00FF00, // xanh lá
                0xFF00FFFF, // cyan
                0xFF0000FF, // xanh dương
                0xFFFF00FF  // tím
        };

        ValueAnimator animator = ValueAnimator.ofFloat(0, 1);
        animator.setDuration(3000); // thời gian chạy 1 vòng
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(animation -> {
            float progress = (float) animation.getAnimatedValue();
            int width = textView.getWidth();
            if (width > 0) {
                // Gradient dịch chuyển từ trái sang phải
                float startX = width * progress;
                float endX = startX + width;
                Shader shader = new LinearGradient(
                        startX, 0, endX, 0,
                        rainbowColors,
                        null,
                        Shader.TileMode.MIRROR
                );
                textView.getPaint().setShader(shader);
                textView.invalidate();
            }
        });
        animator.start();
    }


    private void loadStories() {


            switch (topic) {

                case "Jack the Ripple":

                    listStory.add(new StoryEntity(
                            "Chương 1 – Sương Mù Phủ Lên Phố Cổ",
                            "Phố Cổ London năm 1888 chìm trong lớp sương dày đặc, u tối như một bức màn khổng lồ. "
                                    + "Đêm đó, thanh tra Edmund Hale đi tuần dọc những con ngõ quanh Whitechapel thì nghe tiếng bước chân nhanh và khẽ vang lên từ phía sau.\n\n"
                                    + "Một cậu bé bán báo lao tới, run rẩy: ‘Ngài ơi, có cái bóng lạ đứng bên hẻm kia!’\n\n"
                                    + "Edmund bước vào hẻm, ánh đèn dầu lập lòe chiếu lên một vệt nước đen sậm, loang trên nền gạch ẩm. "
                                    + "Hơi nước bốc lên hòa cùng sương mù, mùi hôi mốc khiến anh rùng mình. "
                                    + "Vệt nước không phải máu, nhưng đen đặc như mực, ánh sáng vàng cũng không xuyên qua nổi.\n\n"
                                    + "Một tờ giấy úp xuống bị gió thổi bay, Edmund lật lên thấy dòng chữ nguệch ngoạc:\n"
                                    + "‘Gợn sóng đầu tiên chỉ là lời chào. Tôi – Jack the Ripple.’\n\n"
                                    + "Bất chợt, một tiếng huýt sáo vang lên từ mái nhà, âm thanh cao và lạnh lẽo, xâm nhập vào tận xương sống Edmund. "
                                    + "Anh lao đến nơi phát ra âm thanh, nhưng bóng đen đã tan vào lớp sương đặc quánh, như chưa từng tồn tại."
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 2 – Dòng Chữ Ẩn Sau Mặt Nước",
                            "Sáng hôm sau, các cư dân lại xôn xao khi thợ sửa ống nước phát hiện một vệt mực đen tương tự cạnh giếng cổ khô. "
                                    + "Edmund cúi xuống kiểm tra, và trong ánh sáng yếu, lớp mực dường như hiện lên những ký tự kỳ bí.\n\n"
                                    + "Dòng chữ nhấp nháy theo ánh sáng:\n"
                                    + "‘Theo dòng nước, anh sẽ thấy chân tướng. Nhưng nước không chảy ngược – còn tôi thì có.’\n\n"
                                    + "Miệng giếng dẫn vào hệ thống cống ngầm bỏ hoang, nơi mùi ẩm mốc nồng nặc hòa với tiếng vọng kỳ quái. "
                                    + "Một lính gác run rẩy: ‘Thưa ngài… có tiếng sáo vọng lên từ dưới cống.’\n\n"
                                    + "Tiếng sáo không du dương mà như một tín hiệu, nhịp điệu đều đặn, lạnh lùng, dẫn Edmund bước vào một mê cung tăm tối. "
                                    + "Mỗi bước chân vang lên trong hầm, tiếng đá ẩm trượt tạo ra âm thanh rùng rợn, khiến tim Edmund đập nhanh."
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 3 – Đêm Trong Cống Ngầm",
                            "Đêm đến, Edmund cùng hai trợ lý quyết định xuống cống. Không gian ẩm ướt, ánh đèn dầu nhấp nháy, "
                                    + "làm bóng các đường ống dài như tay ma quái vươn ra xung quanh.\n\n"
                                    + "Trên tường xuất hiện các ký hiệu kỳ lạ: vòng tròn, mũi tên, những đường gợn sóng đan xen. "
                                    + "Trợ lý thì thầm: ‘Như bản đồ dẫn từ sông Thames vào phố…’\n\n"
                                    + "Bất chợt, tiếng sáo vang vọng khắp đường hầm, dội lại thành vô số âm thanh từ mọi hướng. "
                                    + "Đèn dầu tắt phụt. Khi bật lại, dòng chữ mới xuất hiện trên tường:\n"
                                    + "‘Anh đến đúng nơi rồi, Edmund. Nhưng người anh tìm không ở dưới này… mà phía sau lưng.’\n\n"
                                    + "Ba người quay phắt lại. Ở cửa hầm, bóng người cao gầy khoác áo dài, đội mũ rộng vành. "
                                    + "Hắn cầm một cây sáo trắng, nghiêng đầu, thổi một nốt dài vang lên như tiếng vọng của địa ngục… rồi biến mất."
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 4 – Sự Thật Dưới Lòng Sông",
                            "Vài ngày sau, Edmund nghiên cứu các dấu vết và nhận ra tất cả đều liên quan đến những nơi từng có nước chảy. "
                                    + "Ripple – ‘gợn sóng’. Hắn không phải kẻ sát nhân, mà là người ghi lại những vụ việc bị chôn vùi trong bóng tối thành phố.\n\n"
                                    + "Edmund rà soát hồ sơ cũ và phát hiện: tất cả địa điểm Jack xuất hiện trùng với các vụ mất tích của kỹ sư xây dựng hệ thống cống ngầm 20 năm trước, "
                                    + "một người tên Jack Rippleton.\n\n"
                                    + "Tối hôm đó, Edmund đứng bên bờ sông Thames, nhìn vệt mực đen loang trên mặt nước, tạo thành dòng chữ:\n"
                                    + "‘Không phải kẻ mang bóng đêm nào cũng gieo tội ác. Có người chỉ muốn sự thật trồi lên khỏi đáy nước.’\n\n"
                                    + "Nhìn theo dòng sông cuộn chảy, Edmund biết rằng cuộc rượt đuổi vẫn chưa kết thúc. "
                                    + "Jack the Ripple vẫn đang ẩn hiện trong những gợn sóng, quan sát mọi bước đi của anh, âm thầm, lạnh lùng."
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 5 – Tiếng Thét Trong Đêm",
                            "Một tuần sau, tại kho lưu trữ thành phố, Edmund nhận được báo cáo về tiếng thét vang trong đêm, nhưng khi tới nơi thì trống rỗng. "
                                    + "Các hộp hồ sơ xếp chồng lên nhau, một vài vệt mực đen tạo thành ký hiệu hình sóng lặp lại.\n\n"
                                    + "Edmund chợt cảm nhận có ánh mắt theo dõi, từng tiếng cọt kẹt vang lên trong phòng như muốn cảnh báo sự hiện diện của ai đó. "
                                    + "Một bóng đen vụt qua cửa sổ, và tiếng sáo nhẹ nhàng, như một điệu nhạc u ám, dội vào tai."
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 6 – Mật Thư Bí Ẩn",
                            "Một lá thư không dấu niêm phong được gửi tới Edmund. Chữ viết nguệch ngoạc, mực đen nhòe ra khi gặp ánh sáng: \n"
                                    + "‘Chỉ người biết gợn sóng mới hiểu tôi. Không ai khác. Jack the Ripple.’\n\n"
                                    + "Dòng thư khiến Edmund lạnh sống lưng. Anh nhận ra Jack đang dẫn mình vào một trò chơi trí tuệ, nơi mỗi dấu vết đều là cạm bẫy."
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 7 – Bóng Ma Dưới Cầu",
                            "Edmund đi kiểm tra cầu London vào ban đêm. Sương mù dày đặc, âm thanh gió rít trên sông hòa với tiếng nước vỗ vào trụ cầu.\n\n"
                                    + "Một bóng người thấp thoáng trên cầu, cây sáo trắng trên tay. Khi Edmund tiến lại gần, bóng người biến mất như chưa từng tồn tại. "
                                    + "Trên trụ cầu xuất hiện dòng chữ mực đen: ‘Chỉ kẻ can đảm mới thấy sự thật.’"
                    ));

                    listStory.add(new StoryEntity(
                            "Chương 8 – Lời Hứa Của Gợn Sóng",
                            "Edmund tập hợp tất cả bằng chứng: vết mực đen, dòng chữ, tiếng sáo… và nhận ra: Jack the Ripple không hề là kẻ giết người, "
                                    + "mà là một người muốn sự thật được hé lộ khỏi bóng tối lịch sử.\n\n"
                                    + "Trên bờ sông Thames, những dòng mực đen lần cuối hiện lên: ‘Sự thật sẽ luôn trồi lên. Tôi – Jack the Ripple.’\n\n"
                                    + "Edmund biết rằng trò chơi chưa kết thúc, nhưng giờ anh đã hiểu phần nào ý định của kẻ đứng sau những gợn sóng huyền bí."
                    ));

                    break;
            }

    }



}


